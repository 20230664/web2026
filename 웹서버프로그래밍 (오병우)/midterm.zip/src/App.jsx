import { Routes, Route } from 'react-router-dom'
import PostList from './Pages/PostList'
import PostDetail from './Pages/PostDetail'

function App() {
  return (
    <Routes>
      <Route path="/" element={<PostList />} />
      <Route path="/posts/:id" element={<PostDetail />} />
    </Routes>
  )
}

export default App